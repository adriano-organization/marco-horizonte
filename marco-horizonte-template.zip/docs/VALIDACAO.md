# Validação da revisão — 30/09/2026

- JSON válidos; nove IDs/slugs únicos; fontes associadas a todas as lojas.
- Testes de intervalos, fecho, turnos noturnos, exceções e validade do folheto: passaram.
- Contrastes de texto azul, laranja escuro, texto principal e secundário sobre branco: AA.
- Homepage verificada a 1440 px e 390 px; a 390 px não existe deslocamento horizontal.
- Fotografias da marca, novo slogan, nove lojas e assinatura DevPlus integrados.
- Dados públicos sujeitos a confirmação. Não foram inventados serviços, e-mails nem coordenadas.
- O folheto real continua indisponível; o visualizador usa o PDF de exemplo.

As imagens de pré-visualização estão nesta pasta.

Pesquisa por «Vila Boa» devolveu uma loja. Página Boelhe apresentou morada, telefone clicável, horário, mapa e serviços por loja. Folheto carregou a página 1 de 4 em modo móvel. Sem erros de consola observados nestes percursos. Rodapé revisto visualmente em telemóvel.

## Revisão de 01/10/2026

Nove coordenadas válidas e links de origem validados nos dados. Mapa da homepage com nove marcadores; popup de Lousada com direções para as coordenadas corretas. Galeria: troca automática observada, pausa e avanço manual de 01/03 para 02/03 verificados. Recorte CSS exclui controlos laterais do Instagram.

Verificação móvel a 390 px sem overflow; botões da galeria funcionais. Rio Mau: um pin no mini-mapa e direções para 41.051987,-8.365503. Listagem: nove pins, filtro «Vila Boa» reduz para uma loja e um pin. Sem erros de consola observados.

## Painel e PDF horizontal

PDF fornecido inspecionado: duas páginas de 842 × 595 pontos; ambas renderizadas e revistas no visualizador. Navegação para página 2 de 2 confirmada. Teste completo do painel: seleção de PDF, validação, gravação em IndexedDB, pré-visualização via URL blob e confirmação do botão de folheto ativo no site. Exemplo reposto no fim do teste.

Grelha final: nove cartões, três colunas de igual largura a 1440 px. Link Waze ausente na página de Lousada. Folheto horizontal verificado a 390 px, com navegação, zoom e acesso ao original. Estilos finais do painel revistos em computador.

## Proximidade — 02/10/2026

Testes de distância (Haversine): distância nula, referência de 1 grau no equador e ordenação a partir das coordenadas das nove lojas aprovados. Pesquisa real por Marco de Canaveses e Lousada devolveu escolhas, destacou a loja mais próxima e produziu direções com origem/destino. Limpar localização repôs a ordenação original. A 390 px a largura total permaneceu 390 px. Nenhum novo erro de consola observado na revisão final; corrigida a animação do mapa durante substituições rápidas. Transição curta configurada com 1 s de espera + 0,5 s de saída, remoção aos 1500 ms.

## Autocomplete e Google Maps — 02/10/2026

Pesquisa real validada sem clicar no botão: Rua de Santa Catarina (Porto), Avenida da República (Gaia), Rua de Brito Capelo (Matosinhos), Rua de Camões (Baião) e código postal 4630-286 (Marco de Canaveses). Menos de três caracteres apresenta instrução. Teclas ArrowDown, Enter e Escape verificadas; seleção por clique preenche o campo e calcula a mais próxima. A 390 px não existe overflow horizontal.

Clique em «Como chegar» da loja Lousada abriu outro separador, preservando a página de origem. Botão do destaque também tem target=_blank. Testes de distância, parâmetros de Portugal/preferência regional, códigos postais/freguesias, duplicados e coordenadas inválidas passaram. Geolocalização implementada com tratamento de permissões/erros; não foi recolhida a posição real do utilizador durante os testes.

Pesquisa sem correspondência apresentou a mensagem PT-PT prevista. Sem erros de consola no percurso final.

## Pesquisa regional reforçada — 06/10/2026

Pesquisa por concelho, limite de 40 sugestões, expansão de abreviaturas e prioridade a ruas/Porto/proximidade das lojas. Teste real «R. da Igreja» em Marco de Canaveses devolveu cinco resultados; seleção por teclado identificou Livração a cerca de 2,4 km em linha reta. A 390 px não existe overflow horizontal; consola sem erros no percurso. Testes automatizados de geocodificação, ordenação, distâncias e dados passaram. Captura: pesquisa-regional.png. A rua específica do utilizador ainda não foi identificada, pelo que não se confirma a sua cobertura. A disponibilidade de ruas depende da base Photon/OpenStreetMap.
