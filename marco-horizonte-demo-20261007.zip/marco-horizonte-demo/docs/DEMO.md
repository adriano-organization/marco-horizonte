# Demo Marco Horizonte — 7 de outubro de 2026

## Abrir

Na pasta do projeto, execute `python3 -m http.server 8000 --bind 127.0.0.1`.

- Site: http://127.0.0.1:8000/
- Lojas: http://127.0.0.1:8000/?pagina=lojas
- Painel: http://127.0.0.1:8000/painel/

Use o mesmo navegador e endereço para o site e painel. `localhost` e `127.0.0.1` são origens diferentes.

## Roteiro sugerido (5 minutos)

1. Mostre a nova entrada, a galeria e o folheto digital. No folheto, avance uma página, aumente o zoom e volte aos 100%.
2. Abra «Conheça a sua loja». O catálogo tem sempre as nove lojas, sem pesquisa por nome, filtros por serviço ou campo de morada. Mostre uma ficha e o ponto da loja no mapa.
3. Abra «Encontre a sua loja». Este é o único lugar com pesquisa de morada. Escreva `Rua da Igreja`: as sugestões distinguem as localidades e freguesias; escolha uma para ver a loja mais próxima e outras duas opções.
4. Demonstre `Rua de Santa Catarina 312, Porto` e `4630-286`. A localidade escrita tem prioridade sobre a preferência automática pela região. Pode escolher pelo teclado ou por toque. Os links de direções incluem a morada selecionada como origem.
5. No painel, abra «Lojas e moradas», altere um dado, guarde e atualize o site. Exporte os dados quando terminar.
6. Em «Folheto digital», selecione um PDF, confirme a capa, defina título e validade, pré-visualize e guarde. Abra o site no mesmo navegador.

## Percursos

- `?pagina=lojas`: catálogo das nove lojas.
- `?pagina=encontrar`: pesquisa de morada e cálculo da proximidade.
- Página inicial: convite que abre a pesquisa, sem duplicar o campo de morada.
- Links antigos `?pagina=lojas&morada=...` encaminham para a pesquisa e conservam o texto.

## O que é real

As nove lojas e as coordenadas vêm dos dados existentes e dos pontos Google Maps fornecidos pela marca. A pesquisa é feita com sugestões e geocodificação do Esri ArcGIS World Geocoding Service; as distâncias são calculadas sobre as coordenadas, em linha reta. As direções abrem Google Maps com o destino e, quando disponível, a origem selecionada.

As favoritas, as alterações às lojas e os PDFs persistem no navegador. As moradas pesquisadas e respetivas coordenadas não são guardadas no armazenamento do navegador. As métricas do painel contam os dados efetivamente presentes; não são estatísticas de visitantes. Não existe autenticação, servidor de edição ou publicação remota nesta demo.

## Confirmações ainda necessárias

- Rio Mau: falta a morada postal; as direções funcionam com o ponto da loja.
- Vila Boa de Quires: a anterior morada indicava Vila do Conde e não concordava com o ponto fornecido. Foi retirada. É apresentada a localidade, com indicação de rua/código postal por confirmar.
- Lousada e Sobretâmega: códigos postais incompletos; Livração: morada pouco detalhada.
- Horários, contactos e serviços devem ser confirmados pela marca; o painel permite completá-los.
- O PDF de exemplo é de arquivo, sem validade comercial; não representa ofertas atuais.
- Mapas, pesquisa, fontes e biblioteca PDF precisam de Internet. O motor Esri não garante todas as ruas ou portas nem disponibilidade contínua. Resultados de rua, código postal ou morada interpolada são identificados como aproximados. A pesquisa usa Portugal, com preferência automática pela região e sem limites geográficos que ocultem outras localidades.

## Identidade e imagem

A nova composição ilustrativa de frescos foi criada com a ferramenta nativa ImageGen e está em `assets/frescos-hero-v2.jpg` (original PNG conservado ao lado). É identificada no site como imagem ilustrativa; a galeria continua a usar fotografias fornecidas da marca.

Prompt final usado:

> Use case: ads-marketing. Asset type: premium Portuguese supermarket website hero photograph. Create a high-end editorial still-life food photograph, landscape 3:2 composition. A beautiful abundant rustic woven shopping basket brimming with bright fresh Portuguese market produce: deep red tomatoes on the vine, orange carrots with green tops, green leafy lettuce, a few oranges and lemons, aubergine, crisp apples, and a paper-wrapped rustic baguette. Basket sits on a warm ivory stone table, a few tomatoes and carrots artfully placed on table in foreground. Background is a rich dark forest green wall, dramatic yet warm natural side light from left, realistic shadows, visible fresh vegetable textures, rich colours and refined photographic grain. Basket occupies centre and right, produce lush at top. Shot slightly from above at 45 degrees, close composition. Looks like an expensive food editorial campaign, real photography, nothing cartoonish. No price tags, no signage, no text, no logos, no watermark, no people. Full bleed photo for a rounded website card.

## Verificação

`node tests/validate.mjs` — dados, coordenadas e destinos, horários, exceções, datas, URLs e contrastes.

`node tests/nearest.mjs` — sugestões Esri, seleção por magicKey, prioridade da localidade, porta, código postal exato, precisão, deduplicação, coordenadas e distâncias.

`node tests/content-store.mjs` — persistência, identidade das lojas, reposição, dados inválidos e quota.

As verificações de navegador e os limites detalhados estão em `VALIDACAO.md`. As capturas da demo renovada têm o prefixo `demo-` nesta pasta.

## Referências do motor de pesquisa

A demo usa o endpoint público do geocoder World com `forStorage=false`, apenas para pesquisa temporária. A documentação da Esri descreve [pesquisa simples anónima](https://developers.arcgis.com/python/latest/guide/tutorials/search-for-an-address/), [sugestões](https://developers.arcgis.com/rest/geocode/suggest/) e [resolução da morada](https://developers.arcgis.com/rest/geocode/find-address-candidates/). Para uma publicação comercial, confirmar a modalidade de acesso e os limites aplicáveis à conta de produção.
