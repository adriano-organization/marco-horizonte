import {esc as e} from './utils.js?v=20261006-4';

const pointIsValid = point => Number.isFinite(point?.lat) && Number.isFinite(point?.lng) && Math.abs(point.lat) <= 90 && Math.abs(point.lng) <= 180;
export function distanceKm(a, b) {
 if (!pointIsValid(a) || !pointIsValid(b)) return Infinity;
 const rad = value => value * Math.PI / 180;
 const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lng - a.lng) / 2) ** 2;
 return 6371 * 2 * Math.atan2(Math.sqrt(Math.min(1, h)), Math.sqrt(Math.max(0, 1 - h)));
}
export const normalizeQuery = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
export function expandStreet(query) {
 return String(query ?? '').trim().replace(/\b(\d{4})[ -]?(\d{3})\b/g, '$1-$2')
  .replace(/^r\.\s*/i, 'Rua ').replace(/^av[ª.]?\s+/i, 'Avenida ').replace(/^trav?\.\s*/i, 'Travessa ')
  .replace(/^estr?\.\s*/i, 'Estrada ').replace(/\bdr\.\s*/gi, 'Doutor ').replace(/\bn(?:[.º°]+\s*|\s+)(\d)/gi, '$1');
}
export const postalCodeFrom = query => expandStreet(query).match(/\b\d{4}-\d{3}\b/)?.[0] || '';
export function isStreetQuery(query) {
 return /^(rua\b|r\.|avenida\b|av[ª.]?\s|travessa\b|trav?\.|estrada\b|estr?\.|largo\b|praça\b|praca\b|alameda\b|caminho\b|urbaniza|n\s*\d)/i.test(String(query ?? '').trim());
}
export function houseNumberFrom(query) {
 if (!isStreetQuery(query)) return '';
 const parts = expandStreet(query).replace(/\b\d{4}-\d{3}\b/g, '').split(',');
 const firstPart = /^\s*\d+[a-z]?(?:[/-]\d+[a-z]?)?\s*$/i.test(parts[1] || '') ? `${parts[0]} ${parts[1].trim()}` : parts[0];
 // A street named "Rua 25 de Abril" has a date, not a door number.
 return firstPart.match(/\s(\d+[a-z]?(?:[/-]\d+[a-z]?)?)\s*$/i)?.[1] || '';
}
export function searchUrl(config, query, scope = 'region', streets = false) {
 const url = new URL(config.endpoint);
 const expanded = expandStreet(query);
 const municipality = !['region', 'portugal'].includes(scope) ? scope : '';
 const hasMunicipality = (` ${normalizeQuery(expanded)} `).includes(` ${normalizeQuery(municipality)} `);
 const full = municipality && !hasMunicipality ? `${expanded}, ${municipality}` : expanded;
 url.search = new URLSearchParams({q: full, limit: String(Math.min(50, Math.max(1, Number(config.limit) || 40))), countrycode: 'PT'});
 if (pointIsValid(config.bias)) {
  url.searchParams.set('lat', config.bias.lat);
  url.searchParams.set('lon', config.bias.lng);
  url.searchParams.set('zoom', Number.isFinite(config.bias.zoom) ? config.bias.zoom : 9);
  url.searchParams.set('location_bias_scale', '0.1');
 }
 if (scope !== 'portugal' && Array.isArray(config.regionBbox) && config.regionBbox.length === 4 && config.regionBbox.every(Number.isFinite)) url.searchParams.set('bbox', config.regionBbox.join(','));
 if (streets) {
  url.searchParams.append('layer', 'street');
  if (houseNumberFrom(query)) url.searchParams.append('layer', 'house');
 }
 return url;
}
const uniqueText = values => {
 const seen = new Set();
 return values.map(value => typeof value === 'string' || typeof value === 'number' ? String(value).trim() : '').filter(value => {
  const key = normalizeQuery(value);
  if (!key || seen.has(key)) return false;
  seen.add(key); return true;
 });
};
export function dedupePlaces(places) {
 const seenIds = new Set(); const result = [];
 const addressKey = place => normalizeQuery(place.type === 'house' && place.streetName && place.housenumber ? [place.streetName, place.housenumber, place.postcode, place.city, place.district].join(' ') : place.label);
 for (const place of places) {
  if (!pointIsValid(place) || !place.label) continue;
  if (place.id && seenIds.has(place.id)) continue;
  if (result.some(previous => addressKey(previous) === addressKey(place) && distanceKm(previous, place) < .12)) continue;
  if (place.id) seenIds.add(place.id);
  result.push(place);
 }
 return result;
}
export function placesFrom(data) {
 if (!Array.isArray(data?.features)) return [];
 return dedupePlaces(data.features.flatMap(feature => {
  const p = feature?.properties || {}, c = feature?.geometry?.coordinates;
  if (feature?.geometry?.type !== 'Point' || !Array.isArray(c) || c.length !== 2 || !pointIsValid({lat: c[1], lng: c[0]}) || String(p.countrycode || '').toUpperCase() !== 'PT') return [];
  const type = p.type || (p.osm_key === 'highway' ? 'street' : p.osm_value === 'postcode' ? 'postcode' : 'locality');
  const streetName = p.street || (type === 'street' ? p.name : '');
  const address = streetName ? uniqueText([streetName, p.housenumber]).join(' ') : '';
  const postcode = p.postcode || (p.osm_value === 'postcode' ? p.name : '');
  const title = address || p.name || postcode || p.district || p.city;
  const detail = uniqueText([p.name !== title && p.name !== streetName ? p.name : '', p.locality, p.district, p.city, p.county, p.state, postcode]);
  const label = uniqueText([title, ...detail]).join(', ');
  if (!label) return [];
  return [{lat: c[1], lng: c[0], label, title, description: detail.join(' · '), street: type === 'street' || !!streetName,
   streetName: streetName || '', housenumber: String(p.housenumber || ''), postcode: String(postcode || ''), type,
   name: p.name || p.street || '', region: normalizeQuery(p.state || ''), city: p.city || '', county: p.county || '',
   district: p.district || '', locality: p.locality || '', source: 'photon',
   id: p.osm_id && p.osm_type ? `${p.osm_type}:${p.osm_id}` : ''}];
 }));
}
export function matchingPlaces(places, query, scope = 'region') {
 const postcode = postalCodeFrom(query);
 const house = houseNumberFrom(query);
 const prefix = /^\d{4}$/.test(query.trim()) ? query.trim() : '';
 const municipality = !['region', 'portugal'].includes(scope) ? normalizeQuery(scope) : '';
 return places.filter(place => {
  if (postcode && place.postcode !== postcode) return false;
  if (prefix && !place.postcode?.startsWith(prefix)) return false;
  if (house && place.type === 'house' && place.housenumber && normalizeQuery(place.housenumber) !== normalizeQuery(house)) return false;
  if (municipality && place.source !== 'local') {
   const areas = [place.city, place.county, place.district, place.locality].map(normalizeQuery);
   if (!areas.includes(municipality)) return false;
  }
  return true;
 });
}
export function rankPlaces(places, query, config = {}) {
 const expanded = normalizeQuery(expandStreet(query)), postcode = postalCodeFrom(query), house = houseNumberFrom(query);
 const ignored = new Set(['rua', 'avenida', 'travessa', 'estrada', 'largo', 'praca', 'de', 'do', 'da', 'dos', 'das', 'e']);
 const tokens = expanded.split(' ').filter(token => token && !ignored.has(token));
 const score = place => {
  const label = ` ${normalizeQuery(place.label)} `, name = normalizeQuery(place.title || place.name), street = normalizeQuery(place.streetName);
  let result = tokens.reduce((value, token) => value + (label.includes(` ${token} `) ? 100 : label.includes(token) ? 30 : -100), 0);
  if (name === expanded || street === expanded) result += 160;
  if (name && expanded.startsWith(name)) result += 80;
  if (postcode && place.postcode === postcode) result += 350;
  if (house) result += place.housenumber === house ? 300 : place.housenumber ? -200 : -40;
  if (isStreetQuery(query) && place.street) result += 35;
  if (place.source === 'local' && normalizeQuery(place.name) === expanded) result += 150;
  const distances = (config.storeCoordinates || []).filter(pointIsValid).map(store => distanceKm(place, store));
  if (distances.length) result -= Math.min(100, ...distances) / 10;
  return result;
 };
 return [...places].sort((a, b) => score(b) - score(a));
}
export function localPlacesFromStores(stores, query) {
 const normalized = normalizeQuery(expandStreet(query));
 if (normalized.length < 3) return [];
 return (stores || []).flatMap(store => {
  if (!pointIsValid(store?.coordenadas)) return [];
  const address = store.morada && !store.morada.includes('[A PREENCHER]') ? expandStreet(store.morada) : '';
  const name = String(store.nome || '');
  if (!normalizeQuery(expandStreet(`${name} ${address}`)).includes(normalized)) return [];
  return [{...store.coordenadas, label: uniqueText([name, address]).join(', '), title: name, description: address || 'Localização da loja',
   type: 'store', source: 'local', name, postcode: postalCodeFrom(address), street: false, city: '', id: `store:${store.id}`}];
 });
}
const glyph = name => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${name === 'search' ? 'm21 21-5-5 M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0' : name === 'locate' ? 'M12 2v3m0 14v3M2 12h3m14 0h3 M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0' : 'M12 21s7-6 7-12A7 7 0 0 0 5 9c0 6 7 12 7 12Z M12 6a3 3 0 1 0 0 6 3 3 0 0 0 0-6'}"/></svg>`;
const placeType = place => place.source === 'local' ? 'Loja Marco Horizonte' : place.type === 'house' ? 'Morada' : place.type === 'street' ? 'Rua' : place.postcode && place.title === place.postcode ? 'Código postal · ponto aproximado' : 'Localidade · ponto aproximado';
export function locationMarkup(t, config) {
 return `<section class="location-finder" aria-labelledby="location-heading"><div class="location-heading"><span class="location-icon" aria-hidden="true">${glyph('locate')}</span><div><span class="eyebrow">${e(t.etiqueta)}</span><h2 id="location-heading">${e(t.titulo)}</h2><p>${e(t.descricao)}</p></div></div><form id="location-form" role="search"><label class="field location-scope" for="location-scope">${e(t.zona)}<select id="location-scope"><option value="region">${e(t.regiao)}</option>${(config.municipalities || []).map(name => `<option value="${e(name)}">${e(name)}</option>`).join('')}<option value="portugal">${e(t.portugal)}</option></select></label><label class="field" for="location-query">${e(t.label)}</label><div class="location-input"><div class="address-combobox"><span class="address-search-icon">${glyph('search')}</span><input id="location-query" type="search" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="location-choices" aria-describedby="location-help location-status" maxlength="160" placeholder="${e(t.placeholder)}" autocomplete="off" spellcheck="false" enterkeyhint="search"><ul id="location-choices" role="listbox" aria-label="${e(t.sugestoes)}" hidden></ul></div><button class="btn address-search-button" type="submit" id="address-search">${glyph('search')}<span>Pesquisar</span></button><button class="btn outline" type="button" id="device-location">${glyph('locate')}<span>${e(t.geoBotao || 'Usar a minha localização')}</span></button><button class="btn outline" type="button" id="location-clear" hidden>${e(t.limpar)}</button></div><div class="location-quick-search" aria-label="Exemplos de pesquisa"><span>Experimente</span>${['Marco de Canaveses', 'Penafiel', 'Lousada'].map(query => `<button type="button" data-location-query="${e(query)}">${e(query)}</button>`).join('')}</div></form><p class="location-note" id="location-help">${e(t.ajuda)}</p><p class="location-note">${e(t.privacidade)} <a href="https://photon.komoot.io" target="_blank" rel="noopener">Photon</a> / <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>.</p><div class="location-search-state"><p id="location-status" role="status" aria-live="polite" aria-atomic="true"></p><div class="location-actions" id="location-actions" hidden><button type="button" class="text-link" id="location-retry">Tentar novamente</button><button type="button" class="text-link" id="location-country">Pesquisar em todo o país</button></div></div><div id="nearest-result" aria-live="polite"></div></section>`;
}
export function initLocation(config, t, onSelect) {
 const form = document.querySelector('#location-form'), input = document.querySelector('#location-query'), status = document.querySelector('#location-status');
 if (!form || !input || !status) return;
 const list = document.querySelector('#location-choices'), clear = document.querySelector('#location-clear'), device = document.querySelector('#device-location'), scope = document.querySelector('#location-scope');
 const actions = document.querySelector('#location-actions'), retry = document.querySelector('#location-retry'), country = document.querySelector('#location-country');
 let controller, timer, geoTimer, version = 0, active = -1, places = [], selected = false, composing = false;
 const cache = new Map(), maxSuggestions = Math.min(12, Math.max(1, Number(config.suggestionsLimit) || 8));
 const updateStatus = (message, state = '') => {status.textContent = message; status.dataset.state = state; form.dataset.state = state;};
 function setActions(show, allowCountry = false) {
  if (actions) actions.hidden = !show;
  if (country) country.hidden = !allowCountry || scope.value === 'portugal';
 }
 function close() {list.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); active = -1;}
 function cancel() {
  clearTimeout(timer); clearTimeout(geoTimer); controller?.abort(); controller = null; version++;
  device.disabled = false; input.setAttribute('aria-busy', 'false');
 }
 function resetSelection() {if (selected) {selected = false; onSelect(null);}}
 function render() {
  active = -1; input.removeAttribute('aria-activedescendant');
  list.innerHTML = places.map((place, index) => `<li id="place-${index}" role="option" tabindex="-1" aria-selected="false" data-index="${index}"><span class="place-icon">${glyph('pin')}</span><span class="place-copy"><strong class="place-title">${e(place.title || place.label)}</strong>${place.description ? `<span class="place-description">${e(place.description)}</span>` : ''}<span class="place-meta">${e(placeType(place))}</span></span></li>`).join('');
  list.hidden = !places.length; input.setAttribute('aria-expanded', String(!!places.length));
 }
 function pick(place) {
  if (!pointIsValid(place)) return;
  const house = houseNumberFrom(input.value);
  cancel(); input.value = place.label; places = []; close(); clear.hidden = false; setActions(false);
  const precision = house && !place.housenumber && place.source === 'photon' ? ' O número de porta não está confirmado; este ponto representa a rua.' : '';
  updateStatus(`${t.selecionada} ${place.label}.${precision}`, 'selected'); selected = true; onSelect({...place, approximate: !!precision || !['house', 'store'].includes(place.type)});
 }
 function highlight(index) {
  if (!places.length) return;
  active = (index + places.length) % places.length;
  list.querySelectorAll('[role=option]').forEach((element, i) => element.setAttribute('aria-selected', String(i === active)));
  input.setAttribute('aria-activedescendant', `place-${active}`);
  document.getElementById(`place-${active}`)?.scrollIntoView({block: 'nearest'});
 }
 async function search(query, id) {
  if (id !== version || composing || query.length < 3) return;
  const currentScope = scope.value, request = new AbortController(); controller = request;
  let timedOut = false;
  const timeout = setTimeout(() => {timedOut = true; request.abort();}, 12000);
  const local = matchingPlaces(localPlacesFromStores(config.storeLocations, query), query, currentScope);
  setActions(false); updateStatus(t.aProcurar, 'loading'); input.setAttribute('aria-busy', 'true');
  if (local.length) {places = rankPlaces(local, query, config).slice(0, maxSuggestions); render();}
  try {
   const cacheKey = `${currentScope}|${normalizeQuery(expandStreet(query))}`;
   let result = cache.get(cacheKey);
   if (!result) {
    const load = async streets => {
     const response = await fetch(searchUrl(config, query, currentScope, streets), {signal: request.signal, headers: {'Accept-Language': 'pt-PT,pt;q=0.9'}});
     if (!response.ok) throw new Error(`Geocoder HTTP ${response.status}`);
     const data = await response.json();
     if (!Array.isArray(data?.features)) throw new Error('Invalid geocoder response');
     return matchingPlaces(placesFrom(data), query, currentScope);
    };
    const streetQuery = isStreetQuery(query);
    result = await load(streetQuery);
    if (streetQuery && !result.length && !request.signal.aborted) result = await load(false);
    if (id !== version) return;
    result = rankPlaces(dedupePlaces([...result, ...local]), query, config);
    cache.set(cacheKey, result); if (cache.size > 60) cache.delete(cache.keys().next().value);
   }
   if (id !== version) return;
   places = result.slice(0, maxSuggestions); render();
   updateStatus(places.length ? `${places.length} ${places.length === 1 ? 'localização encontrada' : 'localizações encontradas'}. ${t.escolher}` : postalCodeFrom(query) ? 'Não encontrámos esse código postal exato nesta zona. Confirme os 7 dígitos ou procure pela rua e localidade.' : t.semResultados, places.length ? 'results' : 'empty');
   setActions(!places.length, true);
  } catch (error) {
   if (id !== version || (request.signal.aborted && !timedOut)) return;
   places = rankPlaces(local, query, config).slice(0, maxSuggestions); render();
   updateStatus(local.length ? 'A pesquisa de moradas está indisponível. Pode escolher uma das nossas lojas encontradas abaixo.' : t.erro, 'error'); setActions(true, false);
  } finally {clearTimeout(timeout); if (id === version) {input.setAttribute('aria-busy', 'false'); controller = null;}}
 }
 function changed() {
  cancel(); resetSelection(); close(); places = []; setActions(false); clear.hidden = !input.value;
  const query = input.value.trim(); updateStatus(query && query.length < 3 ? t.minimo : '');
  if (query.length >= 3 && !composing) {const id = version; timer = setTimeout(() => search(query, id), 400);}
 }
 function submit() {
  const query = input.value.trim();
  input.focus();
  if (query.length < 3) {updateStatus(t.minimo); input.focus(); return;}
  if (selected) return;
  cancel(); close(); setActions(false); search(query, version);
 }
 scope.addEventListener('change', changed); input.addEventListener('input', changed);
 input.addEventListener('search', () => {if (!input.value) changed();});
 input.addEventListener('compositionstart', () => {composing = true; cancel(); close();});
 input.addEventListener('compositionend', () => {composing = false; changed();});
 input.addEventListener('keydown', event => {
  if (event.isComposing) return;
  if (event.key === 'Escape') {event.preventDefault(); cancel(); close(); setActions(false); updateStatus('');}
  else if ((event.key === 'ArrowDown' || event.key === 'ArrowUp') && places.length) {
   event.preventDefault(); list.hidden = false; input.setAttribute('aria-expanded', 'true');
   highlight(active < 0 ? event.key === 'ArrowDown' ? 0 : places.length - 1 : active + (event.key === 'ArrowDown' ? 1 : -1));
  } else if (event.key === 'Enter' && !list.hidden && places.length) {event.preventDefault(); pick(places[active < 0 ? 0 : active]);}
  else if (event.key === 'Tab') close();
 });
 form.addEventListener('submit', event => {event.preventDefault(); submit();});
 list.addEventListener('pointerdown', event => {if (event.pointerType === 'mouse') event.preventDefault();});
 list.addEventListener('click', event => {const option = event.target.closest('[data-index]'); if (option) pick(places[Number(option.dataset.index)]);});
 input.addEventListener('focus', () => {if (places.length && !selected) {list.hidden = false; input.setAttribute('aria-expanded', 'true');}});
 const isInSearch = element => form.contains(element) || !!actions?.contains(element);
 form.addEventListener('focusout', () => setTimeout(() => {if (!isInSearch(document.activeElement)) {cancel(); close(); if (status.dataset.state === 'loading') updateStatus('');}}, 0));
 document.addEventListener('pointerdown', event => {if (!isInSearch(event.target)) {cancel(); close(); if (status.dataset.state === 'loading') updateStatus('');}});
 clear.addEventListener('click', () => {cancel(); input.value = ''; places = []; close(); resetSelection(); updateStatus(''); setActions(false); clear.hidden = true; input.focus();});
 retry?.addEventListener('click', submit);
 country?.addEventListener('click', () => {scope.value = 'portugal'; resetSelection(); submit();});
 form.querySelectorAll('[data-location-query]').forEach(button => button.addEventListener('click', () => {
  input.value = button.dataset.locationQuery; scope.value = 'region'; changed(); input.focus(); cancel(); search(input.value, version);
 }));
 device.addEventListener('click', () => {
  cancel(); close(); setActions(false);
  if (!navigator.geolocation) {updateStatus(t.geoIndisponivel, 'error'); return;}
  if (!window.isSecureContext) {updateStatus(t.geoSeguro, 'error'); return;}
  const id = version; device.disabled = true; updateStatus(t.geoProcurar, 'loading');
  const fail = message => {if (id !== version) return; clearTimeout(geoTimer); device.disabled = false; updateStatus(message, 'error');};
  // Some browsers never finish the permission prompt; keep the UI usable regardless.
  geoTimer = setTimeout(() => {if (id !== version) return; cancel(); updateStatus(t.geoTempo, 'error');}, 13000);
  navigator.geolocation.getCurrentPosition(position => {
   if (id !== version) return;
   const {latitude: lat, longitude: lng, accuracy} = position.coords;
   if (!pointIsValid({lat, lng})) {fail(t.geoErro); return;}
   pick({lat, lng, label: t.geoAtual, title: t.geoAtual, type: 'house', source: 'device', accuracy});
   if (Number.isFinite(accuracy) && accuracy > 1000) updateStatus(`${t.selecionada} ${t.geoAtual}. Localização aproximada (margem de ${Math.ceil(accuracy / 1000)} km).`, 'selected');
  }, error => fail(error.code === 1 ? t.geoRecusada : error.code === 3 ? t.geoTempo : t.geoErro), {enableHighAccuracy: false, timeout: 10000, maximumAge: 60000});
 });
}
