# Validação da revisão — 30/09/2026

- JSON válidos; nove IDs/slugs únicos; fontes associadas a todas as lojas.
- Testes de intervalos, fecho, turnos noturnos, exceções e validade do folheto: passaram.
- Contrastes de texto azul, laranja escuro, texto principal e secundário sobre branco: AA.
- Homepage verificada a 1440 px e 390 px; a 390 px não existe deslocamento horizontal.
- Fotografias da marca, novo slogan, nove lojas e assinatura DevPlus integrados.
- Dados públicos sujeitos a confirmação. Não foram inventados serviços, e-mails nem coordenadas.
- O folheto real continua indisponível; o visualizador usa o PDF de exemplo.

As imagens de pré-visualização estão nesta pasta.

Pesquisa por «Vila Boa» devolveu uma loja. Página Boelhe apresentou morada, telefone clicável, horário, mapa e serviços por loja. Folheto carregou a página 1 de 4 em modo móvel. Sem erros de consola observados nestes percursos. Rodapé revisto visualmente em telemóvel.

## Revisão de 01/10/2026

Nove coordenadas válidas e links de origem validados nos dados. Mapa da homepage com nove marcadores; popup de Lousada com direções para as coordenadas corretas. Galeria: troca automática observada, pausa e avanço manual de 01/03 para 02/03 verificados. Recorte CSS exclui controlos laterais do Instagram.

Verificação móvel a 390 px sem overflow; botões da galeria funcionais. Rio Mau: um pin no mini-mapa e direções para 41.051987,-8.365503. Listagem: nove pins, filtro «Vila Boa» reduz para uma loja e um pin. Sem erros de consola observados.

## Painel e PDF horizontal

PDF fornecido inspecionado: duas páginas de 842 × 595 pontos; ambas renderizadas e revistas no visualizador. Navegação para página 2 de 2 confirmada. Teste completo do painel: seleção de PDF, validação, gravação em IndexedDB, pré-visualização via URL blob e confirmação do botão de folheto ativo no site. Exemplo reposto no fim do teste.

Grelha final: nove cartões, três colunas de igual largura a 1440 px. Link Waze ausente na página de Lousada. Folheto horizontal verificado a 390 px, com navegação, zoom e acesso ao original. Estilos finais do painel revistos em computador.

## Proximidade — 02/10/2026

Testes de distância (Haversine): distância nula, referência de 1 grau no equador e ordenação a partir das coordenadas das nove lojas aprovados. Pesquisa real por Marco de Canaveses e Lousada devolveu escolhas, destacou a loja mais próxima e produziu direções com origem/destino. Limpar localização repôs a ordenação original. A 390 px a largura total permaneceu 390 px. Nenhum novo erro de consola observado na revisão final; corrigida a animação do mapa durante substituições rápidas. Transição curta configurada com 1 s de espera + 0,5 s de saída, remoção aos 1500 ms.

## Autocomplete e Google Maps — 02/10/2026

Pesquisa real validada sem clicar no botão: Rua de Santa Catarina (Porto), Avenida da República (Gaia), Rua de Brito Capelo (Matosinhos), Rua de Camões (Baião) e código postal 4630-286 (Marco de Canaveses). Menos de três caracteres apresenta instrução. Teclas ArrowDown, Enter e Escape verificadas; seleção por clique preenche o campo e calcula a mais próxima. A 390 px não existe overflow horizontal.

Clique em «Como chegar» da loja Lousada abriu outro separador, preservando a página de origem. Botão do destaque também tem target=_blank. Testes de distância, parâmetros de Portugal/preferência regional, códigos postais/freguesias, duplicados e coordenadas inválidas passaram. Geolocalização implementada com tratamento de permissões/erros; não foi recolhida a posição real do utilizador durante os testes.

Pesquisa sem correspondência apresentou a mensagem PT-PT prevista. Sem erros de consola no percurso final.

## Pesquisa regional reforçada — 06/10/2026

Pesquisa por concelho, limite de 40 sugestões, expansão de abreviaturas e prioridade a ruas/Porto/proximidade das lojas. Teste real «R. da Igreja» em Marco de Canaveses devolveu cinco resultados; seleção por teclado identificou Livração a cerca de 2,4 km em linha reta. A 390 px não existe overflow horizontal; consola sem erros no percurso. Testes automatizados de geocodificação, ordenação, distâncias e dados passaram. Captura: pesquisa-regional.png. A rua específica do utilizador ainda não foi identificada, pelo que não se confirma a sua cobertura. A disponibilidade de ruas depende da base Photon/OpenStreetMap.

## Revisão da demonstração — 06/10/2026

A revisão introduz uma nova apresentação para a homepage, a pesquisa de lojas, o mapa, as páginas de loja e o painel. Fotografias específicas de lojas e serviços só aparecem quando estão efetivamente associados à loja. O filtro de serviços fica oculto quando não há serviços atribuídos; o catálogo do painel não equivale a disponibilidade em todas as lojas.

### Verificações automatizadas

- `node tests/validate.mjs`: nove lojas e slugs únicos, correspondência entre os nove pins e os destinos dos links Maps, intervalos de abertura, turnos noturnos, exceções, horários incompletos ou inválidos, datas reais do calendário, validade inclusiva do folheto, URLs seguras e contrastes da paleta configurada.
- `node tests/nearest.mjs`: Haversine, ordenação por distância, parâmetros das APIs, abreviaturas, concelho, ruas e códigos postais, números de porta, deduplicação por proximidade e resultados locais das lojas.
- `node tests/content-store.mjs`: persistência das alterações de lojas, conservação da identidade e dos dados originais, reposição, rejeição de dados corrompidos e tratamento de quota.
- Verificação da sintaxe dos módulos alterados: aprovada.
- Contrastes verificados: azul `#173C72` sobre branco 10,90:1; laranja de texto `#AB4212` sobre branco 5,97:1; texto `#142B59` sobre creme `#FAF8F4` 13,03:1; texto secundário `#627087` sobre creme 4,73:1. Estes pares cumprem AA para texto normal.

### Percursos confirmados no navegador

- Homepage em computador: apresentação e captura verificadas, sem mensagens de erro na consola.
- Pesquisa real por «Rua de Santa Catarina 312, Porto»: resultado com número de porta exato, seleção por Enter, nove lojas ordenadas por distância e Rio Mau em primeiro a aproximadamente 22,8 km em linha reta. As direções incluem a origem selecionada e as coordenadas do destino.
- Mapa com agrupamentos: dois grupos de três e duas lojas, mais quatro pins individuais, somam as nove lojas. Clicar num grupo aproxima o mapa e revela as lojas; selecionar Sobretâmega pelo controlo «Ver no mapa» abre o pin e a informação correspondentes. O reset fecha a informação aberta e repõe os grupos. Uma pesquisa sem resultados seguida de «Limpar filtros» restaura as nove lojas.
- Favoritas: guardar Lousada, ativar o filtro e obter uma loja; remover a favorita e obter zero; desativar o filtro e voltar às nove lojas.
- Limpar localização: remove a origem e a ordenação por distância.
- Telemóvel com 390 px: homepage e listagem sem deslocamento horizontal; largura do documento igual à largura do ecrã. Menu abre os links de navegação.
- Painel e site: alterar a descrição de Lousada, guardar, abrir a página pública e confirmar a alteração; repor pelos controlos do painel e confirmar zero alterações locais no resumo. A revisão conserva os dados originais. Captura: `docs/demo-painel.jpg`.
- Folheto em telemóvel: abertura na página 1 de 2, avanço para 2 de 2, zoom a 125%, reposição a 100% e fecho. O scroll e o foco de origem são restaurados. Sem erros de consola neste percurso.

Captura móvel desta revisão: `docs/demo-mobile.jpg`. Os imports dos módulos do site e do painel usam a mesma versão `20261006-4`, para que a demonstração carregue as alterações em conjunto.

### Limites e dados ainda por confirmar

O site deve ser aberto por um servidor HTTP local ou HTTPS. O painel guarda PDFs neste navegador e origem através de IndexedDB e guarda alterações de lojas localmente; não existe autenticação, publicação remota ou partilha automática com outros visitantes. Uma mudança de navegador, dispositivo ou endereço pode apresentar os dados originais. O painel permite exportar as lojas e descarregar o PDF local.

Mapas, pesquisa de moradas, fontes e bibliotecas do PDF dependem de ligação à Internet. O agrupamento de pins próximos usa Leaflet.markercluster 1.5.3 como melhoria opcional: raio de 35 px, sem cobertura ao passar o rato e marcadores individuais a partir do zoom 14. A origem pesquisada fica fora dos grupos. Se o plugin demorar mais de 2,5 s ou falhar, o mapa apresenta marcadores normais. A pesquisa tenta recuperar moradas do Photon e pode apresentar lojas conhecidas como alternativa quando o fornecedor falha. Uma rua, localidade ou código postal não confirma um número de porta; a interface identifica pontos aproximados. As distâncias apresentadas são geográficas, sem estimativa de condução. Geolocalização requer HTTPS ou localhost e permissão do navegador.

As nove coordenadas mantêm os pontos fornecidos pela marca. Rio Mau continua sem morada postal; Livração tem apenas a estrada N312; Lousada e Sobretâmega têm códigos postais incompletos; outras moradas podem carecer de complemento postal. A morada de Vila Boa de Quires que indicava Vila do Conde foi retirada da apresentação e substituída pela localidade coerente com o ponto, com rua e código postal explicitamente pendentes. O horário desta loja continua por confirmar. Não foram inventadas ruas, números, serviços ou contactos para preencher estas lacunas.

O PDF de exemplo continua identificado como exemplo sem validade comercial. Uma gravação no painel só é anunciada como folheto atual dentro das datas definidas.

Verificação final v4: homepage e painel a 390 px sem transbordo horizontal; menus móveis anunciam abertura/fecho corretamente; pausa, retoma e seleção direta da terceira fotografia confirmadas. Novas capturas finais `demo-desktop.jpg`, `demo-mobile.jpg`, `demo-painel.jpg` e `demo-mapa.jpg`. Os três testes e a sintaxe de todos os módulos voltaram a passar após estes ajustes.
